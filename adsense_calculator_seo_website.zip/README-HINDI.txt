WEBSITE SETUP (Hindi/Hinglish)

1) ZIP extract karke saari files ek hi website/root folder mein upload karein.
2) YOUR-DOMAIN.example ko apne final domain se replace karein:
   - har HTML file ke canonical aur og:url
   - robots.txt
   - sitemap.xml
3) contact.html mein REPLACE-WITH-YOUR-EMAIL@example.com ko apne website contact email se replace karein.
4) Website ko public HTTPS URL par publish karein. Abhi yeh files hain, live website nahi.
5) Google Search Console mein property add/verify karein, sitemap.xml submit karein. Indexing/ranking guaranteed nahi.
6) Google AdSense account adult (18+) applicant/parent or guardian ke own Google account se hi manage hona chahiye. Under 18 user khud account na banaye.
7) Site live aur useful original content ke saath ready hone par AdSense mein site add karein. Google jo exact verification snippet de, use <head> ke andar paste karein; phir Verify / Request review.
8) Approval se pehle ads nahi dikhte. Approval ke baad AdSense se ad unit/Auto ads code copy karke approved pages par add karein.
9) ads.txt.example ko ads.txt naam dein aur apne AdSense account se mila exact publisher line paste karein. Example publisher ID ko real ID samajhkar use na karein.

SEO NOTE:
- Is package mein page titles, descriptions, canonical placeholders, robots.txt, sitemap.xml, basic structured data, FAQ and separate information pages hain.
- Yeh technical SEO foundation hai, Google ranking ya AdSense approval guarantee nahi.
- Sirf original, helpful articles add karein. Template-only / thin content se approval mushkil ho sakta hai.
- Google ki policies follow karein; apne ads par click na karein aur kisi ko click karne ko na kahein.
