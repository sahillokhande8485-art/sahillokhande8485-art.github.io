const symbols={INR:"₹",USD:"$",EUR:"€",GBP:"£",AED:"د.إ",CAD:"CA$",AUD:"A$"};let latest="";
const $=id=>document.getElementById(id),num=id=>Number($(id).value);
function fmt(n,c){return symbols[c]+n.toLocaleString("en-IN",{minimumFractionDigits:2,maximumFractionDigits:2})}
function calculate(){
 const v=num("views"),a=num("ads"),t=num("ctr"),c=num("cpc"),cur=$("currency").value;
 if(![v,a,t,c].every(Number.isFinite)||v<0||a<0||t<0||t>100||c<0){$("daily").textContent="Check inputs";return}
 const imp=v*a,clicks=imp*t/100,month=clicks*c,day=month/30,year=month*12,rpm=v?month/v*1000:0;
 $("daily").textContent=fmt(day,cur);$("monthly").textContent=fmt(month,cur);$("yearly").textContent=fmt(year,cur);$("rpm").textContent=fmt(rpm,cur);
 $("impressions").textContent=Math.round(imp).toLocaleString("en-IN");$("clicks").textContent=clicks.toLocaleString("en-IN",{maximumFractionDigits:2});$("ctrOut").textContent=t+"%";$("cpcOut").textContent=fmt(c,cur);
 latest=`AdSense estimate\\nDaily: ${fmt(day,cur)}\\nMonthly: ${fmt(month,cur)}\\nYearly: ${fmt(year,cur)}\\nPage RPM: ${fmt(rpm,cur)}\\nAd impressions: ${imp}\\nEstimated clicks: ${clicks}`;
}
["views","ads","ctr","cpc","currency"].forEach(id=>{ $(id).addEventListener("input",calculate);$(id).addEventListener("change",calculate)});
$("calc").addEventListener("click",calculate);
$("reset").addEventListener("click",()=>{$("views").value=100000;$("ads").value=2;$("ctr").value=2;$("cpc").value=.10;$("currency").value="INR";calculate()});
$("copy").addEventListener("click",async()=>{calculate();try{await navigator.clipboard.writeText(latest);alert("Results copied.")}catch(e){alert(latest)}});
calculate();